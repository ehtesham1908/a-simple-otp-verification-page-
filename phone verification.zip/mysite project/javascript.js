document.getElementById("button").addEventListener("click",function(){
    document.querySelector(".popup").style.display =" flex";
})
document.querySelector(".close").addEventListener("click" ,function(){
    document.querySelector(".popup").style.display="none";
})

move=(from1digit , lastdigit)=>{
    var length = from1digit.length;
    var maxlength = from1digit.getAttribute(maxlength);
    if(length == maxlength){
        document.getElementById(lastdigit).focus();
    }
    if(Key == 8 || key == 46) {
        document.getElementById(from1digit).prev().focus();
    }

}

